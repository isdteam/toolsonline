---
title: Base64 Encode
template: page.pug
js: https://cdn.jsdelivr.net/gh/emn178/hi-base64/build/base64.min.js
method: base64.encode
action: Encode
auto_update: true
hex_input: true
description: Base64 online encode function
keywords: Base64,online,encode
---

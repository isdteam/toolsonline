---
title: HTML Encode
template: page.pug
js: https://cdn.jsdelivr.net/gh/emn178/js-htmlencode/build/htmlencode.min.js
method: htmlEncode
action: Encode
auto_update: true
description: HTML online encode function
keywords: HTML,online,encode
---

---
title: CRC-32
template: page.pug
js: https://cdn.jsdelivr.net/gh/emn178/js-crc/build/crc.min.js
method: crc32
action: Hash
auto_update: true
hex_input: true
description: CRC-32 online hash function
keywords: CRC,CRC-32,online,hash
---
